clear;
clc;
close all;
tic;

% 파일 선택 및 데이터 불러오기
name = uigetfile('*_subt.txt', 'MultiSelect', 'off');
fit = importdata(name);
savename = name(1:end-4);
fit(isnan(fit)) = 0;

tth = fit(:,1);
int = fit(:,2:end) / 10000;

tth_min = min(tth);
tth_max = max(tth);
A_Lo = round(tth_min, 1);
A_Up = round(tth_max, 1);

% 사용자로부터 원하는 스캔 번호 입력 받기
scans = input('원하는 scan 번호를 입력하세요 (예: [60 63 65]): ');
if any(scans > (size(fit, 2) - 1))
    error('입력한 scan 번호가 데이터 범위를 초과합니다.');
end
numScans = length(scans);

% 각 스캔 번호에 대해 데이터를 저장할 cell array 초기화
data_cell = cell(numScans, 1);
baseline_cell = cell(numScans, 1);

% 각 스캔 데이터 추출
for idx = 1:numScans
    k = scans(idx);
    data_i(:,1) = fit(:,1);
    data_i(:,2) = fit(:, k+1) / 10000;

    % baseline subtraction
    y_sub = linspace(mean(data_i(1:2,2)), mean(data_i(end-1:end,2)), length(data_i(:,2)))';
    
    baseline_data(:,1) = data_i(:,1);
    baseline_data(:,2) = data_i(:,2);
    baseline_data(:,3) = y_sub;
    baseline_cell{idx} = baseline_data;
    
    data_i(:,2) = data_i(:,2) - y_sub;
    data_i(data_i(:,2) < 0, 2) = 0;

    data_cell{idx} = data_i;
end

%% CP 결정
figure('units','pixels','pos',[300 100 600 400]);
plot(tth, int(:, scans(end)));
title('피크 중심을 클릭하세요 (왼쪽부터 순서대로)');
xlabel('2\theta(degree)');
ylabel('Intensity(a.u.)');
grid on;
[x, ~, ~] = ginput;
cp = sort(x);  % 왼쪽부터 정렬
fun_num = length(cp);
close;

%% 각 피크에 대해 자동으로 eta 추정
fprintf('\n========================================\n');
fprintf('자동 피크 분석 중...\n');
fprintf('========================================\n');

% 마지막 스캔 데이터로 분석
d = data_cell{end};
x_data = d(:,1);
y_data = d(:,2);

eta_values = zeros(1, fun_num);
H = zeros(1, fun_num);
amplitudes = zeros(1, fun_num);

for i = 1:fun_num
    % 각 피크의 특성 자동 추정
    search_range = 1.5;  % 피크 중심 ±1.5도 범위에서 분석
    [eta_est, fwhm_est, amp_est] = estimate_peak_params(x_data, y_data, cp(i), search_range);
    
    eta_values(i) = eta_est;
    H(i) = fwhm_est;
    amplitudes(i) = amp_est;
    
    fprintf('피크 %d (위치: %.2f°)\n', i, cp(i));
    fprintf('  → 추정 진폭: %.1f\n', amp_est);
    fprintf('  → 추정 FWHM: %.3f°\n', fwhm_est);
    fprintf('  → 추정 Eta: %.2f ', eta_est);
    if eta_est < 0.3
        fprintf('(매우 날카로운 - Gaussian 위주)\n');
    elseif eta_est < 0.5
        fprintf('(날카로운 - Gaussian 쪽)\n');
    elseif eta_est < 0.6
        fprintf('(중간)\n');
    elseif eta_est < 0.7
        fprintf('(약간 넓은 - Lorentzian 쪽)\n');
    else
        fprintf('(넓은 - Lorentzian 위주)\n');
    end
end

fprintf('========================================\n');
fprintf('피팅 옵션:\n');
fprintf('  1. 자동 설정 사용 (추천)\n');
fprintf('  2. Eta 값만 수동 입력\n');
fprintf('  3. Eta와 FWHM 모두 수동 입력\n');
fprintf('========================================\n');
manual_choice = input('선택하세요 (1-3): ');

if manual_choice == 2
    fprintf('\n수동 Eta 입력 모드\n');
    fprintf('현재 자동 추정값: %s\n', mat2str(eta_values));
    new_eta = input('새로운 eta 값을 입력하세요: ');
    if length(new_eta) == fun_num
        eta_values = new_eta;
    else
        warning('입력 개수가 맞지 않아 자동 추정값을 사용합니다.');
    end
elseif manual_choice == 3
    fprintf('\n수동 Eta & FWHM 입력 모드\n');
    fprintf('현재 Eta 추정값: %s\n', mat2str(eta_values));
    fprintf('현재 FWHM 추정값: %s\n', mat2str(H));
    new_eta = input('새로운 eta 값: ');
    new_fwhm = input('새로운 FWHM 값: ');
    if length(new_eta) == fun_num && length(new_fwhm) == fun_num
        eta_values = new_eta;
        H = new_fwhm;
    else
        warning('입력 개수가 맞지 않아 자동 추정값을 사용합니다.');
    end
end

fprintf('\n최종 설정:\n');
fprintf('  Eta 값: %s\n', mat2str(eta_values));
fprintf('  FWHM 값: %s\n', mat2str(H));
fprintf('  진폭 값: %s\n', mat2str(amplitudes));
fprintf('========================================\n\n');

%% 초기 피팅 파라미터 설정
p = zeros(4, fun_num);
p(1,:) = amplitudes;     % 자동 추정된 진폭
p(2,:) = eta_values;     % 자동 추정된 eta
p(3,:) = H;              % 자동 추정된 FWHM
p(4,:) = cp;             % center

% 상하한 설정 - FWHM 범위를 더 넓게
ub = [100000*ones(1,fun_num); ones(1,fun_num); 3*ones(1,fun_num); p(4,:)+1];
lb = [zeros(1,fun_num); zeros(1,fun_num); 0.05*ones(1,fun_num); p(4,:)-1];

% 벡터화
p  = reshape(p,  [], 1);
ub = reshape(ub, [], 1);
lb = reshape(lb, [], 1);

%% Total_PV 함수 정의
Total_PV = @(p,x) 0;
for i = 1:fun_num
    Pseudo_V = @(p,x) ...
        p(4*i-3) .* ( ...
            p(4*i-2) .* ( 2/pi/p(4*i-1) ./ ( 1 + 4/(p(4*i-1)).^2 .* (x - p(4*i)).^2 ) ) + ...
            (1 - p(4*i-2)) .* ( 2./p(4*i-1) .* sqrt(log(2)/pi) ) .* ...
            exp( - (4*log(2)/(p(4*i-1)).^2) .* (x - p(4*i)).^2 ) ...
        );
    Total_PV = @(p,x) Total_PV(p,x) + Pseudo_V(p,x);
end

%% 결과 저장용 배열 초기화
FWHM_arr = zeros(numScans, fun_num+1);
CP_arr   = zeros(numScans, fun_num+1);
sz_arr   = zeros(numScans, fun_num);
eta_arr  = zeros(numScans, fun_num+1);
area_arr = zeros(numScans, fun_num+1);  % *** Area 저장용 추가 ***
peak_fun = cell(numScans, 1);
plot_data_cell = cell(numScans, 1);

%% 각 스캔 번호에 대해 피팅 수행
fprintf('피팅 진행 중...\n');
for idx = 1:numScans
    fprintf('  Scan %d/%d 처리 중...\n', idx, numScans);
    d = data_cell{idx};
    x = d(:,1);
    y = d(:,2);

    options = optimoptions('lsqcurvefit', 'Algorithm','levenberg-marquardt', ...
        'MaxIterations',200, 'Display','off', 'FunctionTolerance',1e-15, ...
        'StepTolerance', 1e-12);
    warning('off');

    % 반복 피팅
    for iter = 1:150
        [p, ~, ~, ~, ~] = lsqcurvefit(Total_PV, p, x, y, lb, ub, options);
    end

    % 고해상도 플롯 데이터 생성
    x_temp = linspace(x(1), x(end), 1000);
    total_fit = Total_PV(p, x_temp);

    % 각 개별 피크 함수 계산 및 Area 계산
    individual_peaks = zeros(length(x_temp), fun_num);
    for j = 1:fun_num
        individual_peaks(:,j) = ...
            p(4*j-3) .* ( ...
                p(4*j-2) .* ( 2/pi/p(4*j-1) ./ ( 1 + 4/(p(4*j-1)).^2 .* (x_temp - p(4*j)).^2 ) ) + ...
                (1 - p(4*j-2)) .* ( 2./p(4*j-1) .* sqrt(log(2)/pi) ) .* ...
                exp( - (4*log(2)/(p(4*j-1)).^2) .* (x_temp - p(4*j)).^2 ) ...
            );
        
        % *** Area 계산 (사다리꼴 적분법) ***
        area_arr(idx, j+1) = trapz(x_temp, individual_peaks(:,j));
        sz_arr(idx,j) = max(individual_peaks(:,j));
        peak_fun{idx} = p;
    end
    
    area_arr(idx, 1) = scans(idx);  % 첫 열에 scan 번호

    % 플롯 데이터 저장
    plot_data.scan_number      = scans(idx);
    plot_data.x_original       = x;
    plot_data.y_original       = y;
    plot_data.x_fitted         = x_temp;
    plot_data.y_total_fit      = total_fit;
    plot_data.individual_peaks = individual_peaks;
    plot_data_cell{idx}        = plot_data;

    % 피팅 결과 플롯
    figure('units','pixels','pos',[970,200,450,600]);
    plot(x, y, 'ko', 'MarkerSize', 4, 'MarkerFaceColor', 'k');
    hold on;
    plot(x_temp, total_fit, 'r-', 'LineWidth', 2.5);
    colors = lines(fun_num);
    for j = 1:length(cp)
        color = colors(j,:);
        area(x_temp, individual_peaks(:,j), 'FaceColor', color, 'FaceAlpha', 0.3, 'EdgeColor', color, 'LineWidth', 1.5);
    end
    hold off;
    xlabel('2\theta(degree)');
    ylabel('Intensity(a.u.)');
    axis([A_Lo A_Up 0 max(y)*1.2]);
    set(gca, 'fontsize', 20);
    grid on;
    
    % 범례 자동 생성 (Area 정보 포함)
    legend_labels = {'Original','Total Fit'};
    for j = 1:fun_num
        legend_labels{end+1} = sprintf('Peak %d (Area=%.1f)', j, area_arr(idx, j+1));
    end
    legend(legend_labels, 'Location','best');
    
    title(sprintf('Scan %d', scans(idx)));

    % 그래프 저장
    saveas(gcf, [savename '_scan_' num2str(scans(idx)) '_fit.png']);
    
    % 파라미터 저장
    p_matrix = reshape(p, 4, []);
    FWHM_arr(idx,1) = scans(idx);
    CP_arr(idx,1)   = scans(idx);
    eta_arr(idx,1)  = scans(idx);
    FWHM_arr(idx,2:end) = p_matrix(3,:);
    CP_arr(idx,2:end)   = p_matrix(4,:);
    eta_arr(idx,2:end)  = p_matrix(2,:);

    p = reshape(p_matrix, [], 1);
end
fprintf('피팅 완료!\n');

toc;

%% 플롯 데이터 저장
for idx = 1:numScans
    scan_num  = scans(idx);
    plot_data = plot_data_cell{idx};
    baseline_data = baseline_cell{idx};

    baseline_filename = [savename '_scan_' num2str(scan_num) '_baseline.txt'];
    fid = fopen(baseline_filename, 'w');
    fprintf(fid, '2theta\toriginal_data\tbaseline\tsubtracted_data\n');
    fclose(fid);
    
    baseline_output = [baseline_data, plot_data.y_original];
    save(baseline_filename, 'baseline_output', '-ascii', '-append');

    original_data = [plot_data.x_original, plot_data.y_original];
    original_filename = [savename '_scan_' num2str(scan_num) '_original_data.txt'];
    save(original_filename, 'original_data', '-ascii');

    total_fit_data = [plot_data.x_fitted', plot_data.y_total_fit'];
    total_fit_filename = [savename '_scan_' num2str(scan_num) '_total_fit.txt'];
    save(total_fit_filename, 'total_fit_data', '-ascii');

    for j = 1:fun_num
        individual_peak_data = [plot_data.x_fitted', plot_data.individual_peaks(:,j)];
        peak_filename = [savename '_scan_' num2str(scan_num) '_peak_' num2str(j) '.txt'];
        save(peak_filename, 'individual_peak_data', '-ascii');
    end

    all_plot_data = [plot_data.x_fitted', plot_data.y_total_fit', plot_data.individual_peaks];
    all_data_filename = [savename '_scan_' num2str(scan_num) '_all_plot_data.txt'];

    header = 'x_fitted\ttotal_fit';
    for j = 1:fun_num
        header = [header '\tpeak_' num2str(j)];
    end

    fid = fopen(all_data_filename, 'w');
    fprintf(fid, '%s\n', header);
    fclose(fid);
    save(all_data_filename, 'all_plot_data', '-ascii', '-append');

    y_fit_interpolated = interp1(plot_data.x_fitted, plot_data.y_total_fit, plot_data.x_original, 'linear', 'extrap');
    comparison_data = [plot_data.x_original, plot_data.y_original, y_fit_interpolated];
    comparison_filename = [savename '_scan_' num2str(scan_num) '_comparison.txt'];

    fid = fopen(comparison_filename, 'w');
    fprintf(fid, 'x_original\ty_original\ty_fitted\n');
    fclose(fid);
    save(comparison_filename, 'comparison_data', '-ascii', '-append');
end

%% 결과 배열 저장 (Area 포함)
FWHM = [scans(:) FWHM_arr(:,2:end)];
CP   = [scans(:) CP_arr(:,2:end)];
SZ   = [scans(:) sz_arr];
AREA = [scans(:) area_arr(:,2:end)];  % *** Area 배열 추가 ***

save([savename '_FWHM.txt'], 'FWHM', '-ascii');
save([savename '_cp.txt'],   'CP',   '-ascii');
save([savename '_sz.txt'],   'SZ',   '-ascii');
save([savename '_area.txt'], 'AREA', '-ascii');  % *** Area 파일 저장 ***

%% Area 비율 계산 및 저장
area_ratio = zeros(numScans, fun_num+1);
area_ratio(:,1) = scans(:);
for idx = 1:numScans
    total_area = sum(area_arr(idx, 2:end));
    for j = 1:fun_num
        area_ratio(idx, j+1) = (area_arr(idx, j+1) / total_area) * 100;  % 백분율
    end
end
save([savename '_area_ratio.txt'], 'area_ratio', '-ascii');  % *** Area 비율 저장 ***

summary_filename = [savename '_fitting_summary.txt'];
fid = fopen(summary_filename, 'w');
fprintf(fid, 'Peak Deconvolution Fitting Summary\n');
fprintf(fid, '==================================\n');
fprintf(fid, 'Number of scans processed: %d\n', numScans);
fprintf(fid, 'Scan numbers: %s\n', mat2str(scans));
fprintf(fid, 'Number of peaks fitted: %d\n', fun_num);
fprintf(fid, 'Peak centers: %s\n', mat2str(cp));
fprintf(fid, 'Initial Eta values: %s\n', mat2str(eta_values));
fprintf(fid, 'Initial FWHM values: %s\n', mat2str(H));
fprintf(fid, 'Initial Amplitude values: %s\n', mat2str(amplitudes));
fprintf(fid, '\nFiles generated for each scan:\n');
fprintf(fid, '- *_baseline.txt: Baseline subtraction details\n');
fprintf(fid, '- *_original_data.txt: Original measured data\n');
fprintf(fid, '- *_total_fit.txt: Total fitting curve (high resolution)\n');
fprintf(fid, '- *_peak_N.txt: Individual peak curves\n');
fprintf(fid, '- *_all_plot_data.txt: All plot data in one file\n');
fprintf(fid, '- *_comparison.txt: Original vs fitted data comparison\n');
fprintf(fid, '- *_fit.png: Fitting plot image\n');
fprintf(fid, '- *_area.txt: Peak area values\n');
fprintf(fid, '- *_area_ratio.txt: Peak area ratios (percentage)\n');
fclose(fid);

fprintf('\n========================================\n');
fprintf('모든 작업 완료!\n');
fprintf('자동 추정 초기값:\n');
fprintf('  Eta: %s\n', mat2str(eta_values));
fprintf('  FWHM: %s\n', mat2str(H));
fprintf('  Amplitude: %s\n', mat2str(amplitudes));
fprintf('\n생성된 결과 파일:\n');
fprintf('  - %s_FWHM.txt (반치폭)\n', savename);
fprintf('  - %s_cp.txt (피크 위치)\n', savename);
fprintf('  - %s_sz.txt (피크 높이)\n', savename);
fprintf('  - %s_area.txt (피크 면적) *** NEW ***\n', savename);
fprintf('  - %s_area_ratio.txt (면적 비율 %%) *** NEW ***\n', savename);
fprintf('  - %s\n', summary_filename);
fprintf('========================================\n');

%% ========== 함수 정의 (파일 끝에 위치) ==========
function [eta_est, fwhm_est, amp_est] = estimate_peak_params(x_data, y_data, peak_center, search_range)
    % 피크 중심 근처 데이터 추출
    idx_range = find(abs(x_data - peak_center) < search_range);
    
    if isempty(idx_range)
        % 데이터가 없으면 기본값 반환
        eta_est = 0.5;
        fwhm_est = 0.5;
        amp_est = 10000;
        return;
    end
    
    x_local = x_data(idx_range);
    y_local = y_data(idx_range);
    
    % 피크 최대값 찾기
    [peak_height, max_idx] = max(y_local);
    
    if peak_height < 1e-6
        % 피크가 너무 작으면 기본값
        eta_est = 0.5;
        fwhm_est = 0.5;
        amp_est = 10000;
        return;
    end
    
    peak_pos = x_local(max_idx);
    amp_est = peak_height * 10000;  % 진폭 추정
    
    % Half Maximum 계산
    half_max = peak_height / 2;
    
    % FWHM 추정 - 더 정확한 방법
    left_half = find(x_local < peak_pos);
    right_half = find(x_local > peak_pos);
    
    % 왼쪽 half maximum
    if ~isempty(left_half)
        [~, left_idx] = min(abs(y_local(left_half) - half_max));
        left_pos = x_local(left_half(left_idx));
    else
        left_pos = peak_pos - 0.25;
    end
    
    % 오른쪽 half maximum
    if ~isempty(right_half)
        [~, right_idx] = min(abs(y_local(right_half) - half_max));
        right_pos = x_local(right_half(right_idx));
    else
        right_pos = peak_pos + 0.25;
    end
    
    fwhm_est = abs(right_pos - left_pos);
    
    % 피크 형태 분석 (Gaussian vs Lorentzian)
    % 10%, 50%, 90% 높이에서의 폭 비율로 판단
    h_10 = peak_height * 0.1;
    h_50 = peak_height * 0.5;
    h_90 = peak_height * 0.9;
    
    % 각 높이에서의 폭 계산
    width_10 = calculate_width_at_height(x_local, y_local, peak_pos, h_10);
    width_50 = calculate_width_at_height(x_local, y_local, peak_pos, h_50);
    width_90 = calculate_width_at_height(x_local, y_local, peak_pos, h_90);
    
    % 폭 비율로 피크 형태 판단
    if width_50 > 0 && width_90 > 0
        ratio = width_10 / width_50;
        
        % Gaussian: ratio ~ 2.4
        % Lorentzian: ratio ~ 3.2
        if ratio < 2.7
            eta_est = 0.2 + (ratio - 2.0) * 0.5;  % 2.0~2.7 → 0.2~0.55
        else
            eta_est = 0.5 + (ratio - 2.7) * 0.4;  % 2.7~3.5 → 0.5~0.82
        end
        
        % 범위 제한
        eta_est = max(0.15, min(0.85, eta_est));
    else
        % 기본 FWHM 기반 추정
        if fwhm_est < 0.3
            eta_est = 0.25;
        elseif fwhm_est < 0.5
            eta_est = 0.35;
        elseif fwhm_est < 0.8
            eta_est = 0.5;
        elseif fwhm_est < 1.2
            eta_est = 0.65;
        else
            eta_est = 0.75;
        end
    end
    
    % FWHM 범위 제한
    fwhm_est = max(0.1, min(2.5, fwhm_est));
end

function width = calculate_width_at_height(x, y, center, height)
    % 특정 높이에서의 피크 폭 계산
    idx_above = find(y >= height);
    
    if length(idx_above) < 2
        width = 0;
        return;
    end
    
    x_above = x(idx_above);
    left_most = min(x_above);
    right_most = max(x_above);
    
    width = right_most - left_most;
end


