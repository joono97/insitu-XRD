%% XRD Li–2θ Contour (v33-fix: right Y ticks aligned to capacity, font 30)
close all; clc;

%% 1) 파일 선택 및 데이터 로드
[filename, filepath] = uigetfile('*_subt.txt', 'XRD 데이터 파일을 선택하세요');
if isequal(filename,0)
    disp('파일 선택이 취소되었습니다.'); return;
end
full_data_path = fullfile(filepath, filename);
data = load(full_data_path);
tth    = data(:,1);          
subint = data(:,2:end);      

%% 2) Z-score Normalization 선택
fprintf('\n=== Normalization Method ===\n');
fprintf('1. Yes (Apply Z-score normalization)\n');
fprintf('2. No  (Use raw background-subtracted intensity)\n');
choice = input('Enter your choice (1 or 2): ');
if isempty(choice) || ~ismember(choice,[1 2]), choice = 2; end

if choice == 1
    fprintf('Applying Z-score normalization...\n');
    normalized_subint = zeros(size(subint));
    for c = 1:size(subint,2)
        v  = subint(:,c);
        mu = mean(v); sg = std(v);
        if sg > 0, normalized_subint(:,c) = (v - mu) / sg;
        else,      normalized_subint(:,c) = (v - mu);
        end
    end
else
    fprintf('Using raw background-subtracted intensity.\n');
    normalized_subint = subint;
end

%% 3) Li_contents 로드
li_file = fullfile(filepath, 'Li_contents.txt');
if ~exist(li_file, 'file')
    error('Li_contents.txt 가 %s 폴더에 없습니다.', filepath);
end
li_data     = load(li_file);
li_contents = li_data(:,1);

if length(li_contents) ~= size(subint,2)
    error('Li 함량 개수(%d) ≠ XRD 스캔 수(%d).', length(li_contents), size(subint,2));
end

%% 4) 눈금 숫자 표시 여부
fprintf('\n=== Axis Numbers Display Options ===\n');
show_2theta_numbers = (input('Show 2θ axis numbers (bottom)? 1:Yes 2:No > ')==1);
show_li_numbers     = (input('Show Li contents axis numbers (left)? 1:Yes 2:No > ')==1);
show_cap_numbers    = (input('Show capacity axis numbers (right)? 1:Yes 2:No > ')==1);

%% 5) Figure & 메인 컨투어
fig = figure('Units','pixels','Position',[100 50 600 800]);   % 크게
ax  = axes('Parent',fig,'ActivePositionProperty','position');

contourf(ax, tth, li_contents, normalized_subint.', 128, 'LineColor','none');
colormap(ax, jet(255));

set(ax,'Box','off','Layer','top', ...
       'YDir','normal','TickDir','in', ...
       'FontSize',36,'LineWidth',3.5, ...
       'XMinorTick','on','YMinorTick','off', ...   % Y minor off
       'TickLength',[0.036 0.036]);                % X 기준 맞춤
axis(ax,'tight');
pbaspect(ax,[1 2 1]);
xlabel(ax,''); ylabel(ax,'');

if ~show_2theta_numbers, ax.XTickLabel = {}; end
if ~show_li_numbers,     ax.YTickLabel = {}; end

%% 6) caxis
auto_cmin = min(normalized_subint(:));
auto_cmax = max(normalized_subint(:));
fprintf('\n--- Caxis Range Suggestion ---\nAuto caxis: [%.4f, %.4f]\n', auto_cmin, auto_cmax);
usr = input('Enter caxis [min max] or press Enter: ','s');
if isempty(usr)
    crng = [auto_cmin, auto_cmax];
else
    v = str2num(usr); %#ok<ST2NM>
    if numel(v)==2 && all(isfinite(v)), crng = sort(v(:)).'; else, crng = [auto_cmin, auto_cmax]; end
end
caxis(ax, crng);

%% 7) 오른쪽 Capacity 축
li_min = min(li_contents); li_max = max(li_contents);
cap_min = (li_min - 0.0800) * 275;
cap_max = (li_max - 0.0800) * 275;

t0 = ceil(cap_min/30)*30; t1 = floor(cap_max/30)*30;
if t1 < t0, t0 = floor(cap_min/30)*30; t1 = ceil(cap_max/30)*30; end
cap_ticks  = t0:30:t1;                       % capacity tick labels (mAh/g)
cap_li_pos = (cap_ticks/275) + 0.07007;      % capacity tick positions in Li space

yyaxis(ax,'right');
ylim(ax,[li_min li_max]);
ax.YAxis(2).TickValues = cap_li_pos;
if show_cap_numbers
    ax.YAxis(2).TickLabels = compose('%.0f', cap_ticks); % mAh/g 숫자
else
    ax.YAxis(2).TickLabels = {};
end
ax.YAxis(2).Color     = [0 0 0];
ax.YAxis(2).Exponent  = 0;
ax.YAxis(2).MinorTick = 'off';      % 오른쪽 Y minor off
ax.YAxis(2).LineWidth = 1.5;
ylabel(ax,'');
yyaxis(ax,'left');                    % 이후 연산은 다시 왼쪽 축 기준
ylim(ax,[li_min li_max]);          % 왼쪽 축 범위를 Li 범위로 명시
ytick_start = ceil(li_min*10)/10;  % 0.1 격자에 맞춰 시작점 올림
ytick_end   = floor(li_max*10)/10; % 0.1 격자에 맞춰 끝점 내림
ytick_vals  = ytick_start:0.1:ytick_end;
set(ax,'YTick', ytick_vals);


%% 8) 컨투어 경계선 (먼저 그림)
hold(ax,'on');
xl2 = xlim(ax); yl2 = ylim(ax);
plot(ax,[xl2(1) xl2(2)],[yl2(1) yl2(1)],'k-','LineWidth',1.5);
plot(ax,[xl2(1) xl2(1)],[yl2(1) yl2(2)],'k-','LineWidth',1.5);
plot(ax,[xl2(2) xl2(2)],[yl2(1) yl2(2)],'k-','LineWidth',1.5);
plot(ax,[xl2(1) xl2(2)],[yl2(2) yl2(2)],'k-','LineWidth',1.5);
hold(ax,'off');

%% 9) 위쪽 눈금 (major만, 숫자 없음, 짧게)
xl = xlim(ax); yl = ylim(ax);
xt = ax.XTick;
hold(ax,'on');
set(ax,'Clipping','off');
Lmaj = diff(yl)*0.02;
for k = 1:numel(xt)
    if xt(k) >= xl(1) && xt(k) <= xl(2)
        plot(ax,[xt(k) xt(k)],[yl(2) yl(2)-Lmaj],'k-','LineWidth',3.5,'Clipping','off');
    end
end
hold(ax,'off');

%% 10) Y축 눈금 커스텀 (왼쪽=Li, 오른쪽=Capacity 위치로 각각)
hold(ax,'on');
xlims = xlim(ax);
tick_len_y = diff(xlims)*0.03;   % Y축 커스텀 눈금 길이

% 왼쪽 Y축 눈금 위치: Li축의 major tick 사용
yticks_left = ax.YTick;
for k = 1:numel(yticks_left)
    plot(ax,[xlims(1), xlims(1)+tick_len_y], ...
         [yticks_left(k), yticks_left(k)], 'k-','LineWidth',3.5);
end

% 오른쪽 Y축 눈금 위치: capacity 축의 위치(cap_li_pos) 사용 ★핵심 수정
yticks_right = cap_li_pos;   % capacity tick positions (in Li space)
for k = 1:numel(yticks_right)
    if yticks_right(k) >= yl(1) && yticks_right(k) <= yl(2)
        plot(ax,[xlims(2), xlims(2)-tick_len_y], ...
             [yticks_right(k), yticks_right(k)], 'k-','LineWidth',3.5);
    end
end
hold(ax,'off');

% 기존 Y축 눈금 숨기기(선 중복 방지, 라벨은 유지)
ax.YAxis(1).TickLength = [0 0];
ax.YAxis(2).TickLength = [0 0];

%% 11) Colorbar Figure
fig_cb = figure('Units','pixels','Position',[750 50 200 800]);
axes('Parent',fig_cb,'Visible','off');
colormap(fig_cb, jet(255));
c = colorbar('FontSize',32,'LineWidth',1.5);
c.Position = [0.3 0.1 0.4 0.8];
caxis(crng);

fprintf('\nPlot completed successfully (v33-fix: right Y ticks aligned to capacity).\n');
