%% Unified XRD Data Analysis - Synchrotron and Lab XRD
% Integrated version for both synchrotron and lab XRD data analysis
% Suitable for layered cathode materials (NCM, NCA, NCMA, LCO, etc.) and graphite
clear;
clc;
close all;

%% Data Source Selection
fprintf('=== XRD Data Analysis - Source Selection ===\n');
fprintf('1. Synchrotron (beamline data - .dat files)\n');
fprintf('2. Lab XRD (.xy files)\n');
data_source = input('Select data source (1 or 2): ');

if isempty(data_source) || (data_source ~= 1 && data_source ~= 2)
    fprintf('Invalid selection. Using synchrotron data.\n');
    data_source = 1;
end

%% Parameters setup based on data source
if data_source == 1  % Synchrotron
    fprintf('\n=== Synchrotron Data Parameters ===\n');
    lambda = 1.5405929; %% Cu Ka1 = 1.5405929 
    electrode = 1; %0 = cathode, 1 = anode, 2 = fullcell
    from = input('Enter starting scan number: ');
    to = input('Enter ending scan number: ');
    beamline = input('Enter beamline (Else or 6D): ', 's');
    
    if isempty(from), from = 1; end
    if isempty(to), to = 161; end
    if isempty(beamline), beamline = "5A"; end
    
    ScanNo = from - 1;
    num = to + 1 - from;
    
    measurement_interval = input('Enter measurement interval in seconds (default: 150): ');
    if isempty(measurement_interval), measurement_interval = 150; end
    
    name = uigetfile(['*' num2str(from) '_C.dat']);
    
    if name == 0
        error('No file selected. Please restart and select a file.');
    end
    
    time_axis = (0:(num-1)) * measurement_interval / 3600; % Convert to hours
    name = name(1:end-9);
    
else  % Lab XRD
    fprintf('\n=== Lab XRD Data Parameters ===\n');
    from = input('Enter starting scan number: ');
    to = input('Enter ending scan number: ');
    
    if isempty(from), from = 1; end
    if isempty(to), to = 314; end
    
    num = to + 1 - from;
    name = uigetfile('*.xy');
    
    if name == 0
        error('No file selected. Please restart and select a file.');
    end
    
    timeterm = input('Enter time term (default: 4): ');
    if isempty(timeterm), timeterm = 4; end
    
    measurement_interval = timeterm; % For consistency in reporting
    time_axis = linspace(1, num, num) * timeterm / 3600; % Convert to hours
    name = name(1:end-4);  % Remove .xy extension
end

%% Normalization parameters
N_range_i = 10;     
N_range_f = 90;  

%% Define peak database for NCM and Graphite
peak_database = struct();

% NCM peaks (2theta positions for Cu Ka1)
peak_database.Cat_003 = [17.0, 20.3];    % NCM 003
peak_database.Cat_101 = [36.0, 38.0];    % NCM 101  
peak_database.Cat_104 = [42.0, 44.5];    % NCM 104
peak_database.Cat_105 = [47.5, 49.5];    % NCM 105
peak_database.Cat_107 = [57.7, 59.5];    % NCM 107
peak_database.Cat_113 = [67.5, 70.5];    % NCM 113

% Graphite peaks
peak_database.Graphite_002 = [25.0, 27.0]; % Graphite 002
peak_database.Graphite_2nd = [41.0, 47.0]; % 2nd Graphite peak

% Additional useful peaks
peak_database.SEI = [10.0, 17.5];        % SEI layer
peak_database.Spinel = [30.0, 33.0];     % Spinel phase
peak_database.All_range = [10.0, 90.0];  % Full range

%% Peak selection interface
fprintf('\n=== XRD Peak Analysis Selection ===\n');
fprintf('Available peaks (suitable for NCM, NCA, NCMA, LCO, etc.):\n');
peak_names = fieldnames(peak_database);
for i = 1:length(peak_names)
    range = peak_database.(peak_names{i});
    if startsWith(peak_names{i}, 'p')
        % For layered cathode peaks
        display_text = ['(' peak_names{i}(2:end) ') reflection'];
    else
        % For other peaks
        display_text = peak_names{i};
    end
    fprintf('%d. %s (%.1f° - %.1f°)\n', i, display_text, range(1), range(2));
end

fprintf('\nSelect peaks to analyze:\n');
fprintf('Enter peak numbers separated by spaces (e.g., 1 2 3 7): ');
selected_indices = input('', 's');
selected_indices = str2num(selected_indices);

if isempty(selected_indices)
    fprintf('No peaks selected. Using default layered cathode peaks.\n');
    selected_indices = [1, 2, 3, 4, 5, 6]; % Layered cathode peaks by default
end

% Validate selection
selected_indices = selected_indices(selected_indices >= 1 & selected_indices <= length(peak_names));
selected_peaks = peak_names(selected_indices);

fprintf('\nSelected peaks for analysis:\n');
for i = 1:length(selected_peaks)
    range = peak_database.(selected_peaks{i});
    peak_name = selected_peaks{i};
    if startsWith(peak_name, 'p')
        % For layered cathode peaks
        display_text = ['(' peak_name(2:end) ') reflection'];
    else
        % For other peaks
        display_text = peak_name;
    end
    fprintf('- %s (%.1f° - %.1f°)\n', display_text, range(1), range(2));
end

%% Initialize storage for selected peaks
contour_data = struct();
x_data = struct();

%% Data processing loop
fprintf('\nProcessing data files...\n');
h = waitbar(0, 'Reading data into memory');

for i = 1:num  % # of data files
    
    %% File loading based on data source
    if data_source == 1  % Synchrotron
        % File loading logic for synchrotron data
        if beamline == "6D"
            if (ScanNo+i) < 10
                x = importdata([name '000' num2str(ScanNo+i) '_C.dat']);
            elseif (ScanNo + i) >= 10  && 100 > (ScanNo + i)
                x = importdata([name '00' num2str(ScanNo+i) '_C.dat']);
            elseif (ScanNo + i) >= 100 && 1000 > (ScanNo + i)
                x = importdata([name '0' num2str(ScanNo+i) '_C.dat']);
            elseif (ScanNo + i) >= 1000
                x = importdata([name num2str(ScanNo+i) '_C.dat']);
            end
        else
            if (ScanNo+i) < 10
                x = importdata([name '00' num2str(ScanNo+i) '_C' '.dat']);
            elseif (10 <= (ScanNo+i)) && (ScanNo+i < 100)
                x = importdata([name '0' num2str(ScanNo+i) '_C'  '.dat']);
            elseif (100 <= (ScanNo+i)) && (ScanNo+i < 1000)
                x = importdata([name  num2str(ScanNo+i)  '_C' '.dat']);
            end
        end
        
        % Data processing for synchrotron
        a = x.data;
        tth = 2*180/pi*asin(a(:,1)*lambda/4/pi); % Q to 2theta
        int = a(:,2);
        
    else  % Lab XRD
        % File loading logic for lab XRD
        x = importdata([name num2str(from + i - 1) '.xy']);
        
        % Data processing for lab XRD
        a = x.data;
        tth = a(:,1);  % Already in 2theta
        int = a(:,2);
    end
    
    %% Unified normalization (background-based)
    Norm_logic = (tth >= N_range_i) & (tth <= N_range_f);
    Norm = int(Norm_logic);
    NormX = tth(Norm_logic);
    
    % Background-based normalization
    % 저각, 고각에서 하나씩 범위 잡아주기
    % but subtraction 시 spectrum 마다 baseline 뜨는 정도가 다르면 다시 각도를 fit하게 잡아주어야 함
    % ex) graphite의 경우 피크가 아예 없는 부분을 골라서 아래와 같이 설정함
    % Ratio_logic = (tth > 22.8870 ) & (tth < 23.11) ;
    % Ratio_logic_2 = (tth > 29.02) & (tth < 29.89) ;
Ratio_logic = (tth > 22) & (tth < 24);
Ratio_logic_2 = (tth > 50) & (tth < 52);
    
    if sum(Ratio_logic) > 0 && sum(Ratio_logic_2) > 0
        Norm_ratio = int(Ratio_logic);    
        Norm_ratio_2 = int(Ratio_logic_2);  
        ratio = mean(Norm_ratio);
        ratio_2 = mean(Norm_ratio_2);
        mean_ratio = (ratio + ratio_2) / 2;
        
        if mean_ratio > 0
            NormY = Norm ./ mean_ratio;
        else
            NormY = Norm ./ max(Norm);  % Fallback to max normalization
        end
    else
        NormY = Norm ./ max(Norm);  % Fallback to max normalization
    end
    
    %% Process each selected peak
    for j = 1:length(selected_peaks)
        peak_name = selected_peaks{j};
        peak_range = peak_database.(peak_name);
        Lo_bound = peak_range(1);
        Up_bound = peak_range(2);
        
        % Extract peak region
        peak_logic = (NormX >= Lo_bound) & (NormX <= Up_bound);
        cut_data = NormY(peak_logic);
        
        % Store data
        if i == 1
            contour_data.(peak_name) = zeros(length(cut_data), num);
            x_data.(peak_name) = NormX(peak_logic);
        end
        
        if length(cut_data) == size(contour_data.(peak_name), 1)
            contour_data.(peak_name)(:, i) = cut_data * 1000;
        else
            % Handle size mismatch by interpolation or padding
            if length(cut_data) > 0
                expected_length = size(contour_data.(peak_name), 1);
                if length(cut_data) > expected_length
                    % Trim the data
                    contour_data.(peak_name)(:, i) = cut_data(1:expected_length) * 1000;
                else
                    % Pad with NaN
                    padded_data = [cut_data; NaN(expected_length - length(cut_data), 1)];
                    contour_data.(peak_name)(:, i) = padded_data * 1000;
                end
            end
        end
    end
    
    progress_percent = (i/num)*100;
    progress_text = ['Processing: ' num2str(i) '/' num2str(num) ' files (' num2str(progress_percent, '%.1f') '%)'];
    waitbar(i/num, h, progress_text);
end

close(h);

%% Plotting
fprintf('\nGenerating plots...\n');

figure_positions = [
    [100, 50, 350, 450];
    [500, 50, 350, 450];
    [900, 50, 350, 450];
    [100, 550, 350, 450];
    [500, 550, 350, 450];
    [900, 550, 350, 450];
    [1300, 50, 350, 450];
    [1300, 550, 350, 450];
];

color = jet(255);

for j = 1:length(selected_peaks)
    peak_name = selected_peaks{j};
    
    if j <= length(figure_positions)
        pos = figure_positions(j, :);
    else
        pos = [100 + mod(j-1, 3)*400, 50 + floor((j-1)/3)*500, 350, 450];
    end
    
    figure('units', 'pixels', 'pos', pos);
    
    x_plot = x_data.(peak_name);
    z_plot = contour_data.(peak_name).';  % Use .' instead of transpose()
    
    % Both use time axis now
    y_plot = time_axis;
    y_label = 'Time (h)';
    
    contourf(x_plot, y_plot, z_plot, 36, 'LineColor', 'none'); 
    colormap(color);
    xlabel('2theta (Cu K_{\alpha1})'); 
    ylabel(y_label); 
    
    % Format peak name for display
    if startsWith(peak_name, 'p')
        % For layered cathode peaks (p003 -> (003))
        display_name = ['(' peak_name(2:end) ')'];
    else
        % For other peaks, replace underscores with spaces
        display_name = strrep(peak_name, '_', ' ');
    end
    
    title(display_name);
    colorbar;
    set(gca, 'FontSize', 12);
end

%% Save data
fprintf('\nSaving data files...\n');

for j = 1:length(selected_peaks)
    peak_name = selected_peaks{j};
    
    x_save = x_data.(peak_name);
    contour_save = contour_data.(peak_name);
    
    fit_data = [x_save, contour_save];
    
    
    filename = [name peak_name '.txt'];

    save(filename, 'fit_data', '-ascii');
    fprintf('Saved: %s\n', filename);
end

fprintf('\nAnalysis complete!\n');
if data_source == 1
    completion_text = ['Processed ' num2str(length(selected_peaks)) ' peaks across ' num2str(num) ' time points (synchrotron data, ' num2str(measurement_interval) ' second intervals)'];
    fprintf('%s\n', completion_text);
    time_text = ['Total measurement time: ' num2str(max(time_axis), '%.2f') ' hours'];
    fprintf('%s\n', time_text);
else
    completion_text = ['Processed ' num2str(length(selected_peaks)) ' peaks across ' num2str(num) ' time points (lab XRD data)'];
    fprintf('%s\n', completion_text);
    time_text = ['Total measurement time: ' num2str(max(time_axis), '%.2f') ' hours'];
    fprintf('%s\n', time_text);
end

