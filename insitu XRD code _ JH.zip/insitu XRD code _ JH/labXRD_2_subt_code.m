 
clear;
clc;
% close all;
name = uigetfile('*.txt', 'MultiSelect','on');
peak = importdata(name);
save_name = name(1:end-4);
peak(isnan(peak))=0;

ul = 1300000000
ll = -5000
limit_to = 3000
                                                       
timeterm = 300;

tth = peak(:,1);
int = peak(:,2:end);

int(int>ul) = limit_to;
int(int<ll) = 0;

% 
lb = round(min(tth),1);
ub =round(max(tth),1);
% lb = 50
% ub = 400
Numdata = size(peak,2)-1;
ScanNum = linspace(1,Numdata,Numdata)';


%% smooth
% for i = 1:Numdata;
%     int(:,i) = smooth(int(:,i),3);
% end
 
%% plot

figure('units', 'pixels', 'pos',[50 50 1500 800]); 
hold on
for i = 1: Numdata
    plot(tth, int(:,i))%,'Color',color(i,:)) ; 
end
[x,y,button] = ginput ;  
close;

k = size(button)
k = k(1,1);
% % % % % % % % % % % % % for i = 1:k
% % % % % % % % % % % % %     if y(i,1)<0;
% % % % % % % % % % % % %     y(i,1)=0;
% % % % % % % % % % % % %     end
% % % % % % % % % % % % % end
intBK = interp1(x,y,tth) ; 

% figure('units', 'pixels','pos' ,[100 100 700 700]);
hold on
for i = 1 : Numdata
   subint(:,i)=int(:,i)-intBK; 
% % % % % % % % % % % % %    if subint<0;
% % % % % % % % % % % % %        subint=0;
% % % % % % % % % % % % %    end
end
hold off


time = ScanNum*timeterm/3600;

% figure('units', 'pixels','pos' ,[100 100 600 800]);
% colormap(jet(255));
% contourf(tth,time,subint',50,'LineColor','none');
% xlabel('2theta (Cu K_{\alpha1})', 'fontsize', 15) ; ylabel('Time (h)','fontsize', 15); 
% set(gca,'fontsize',30)
% xlim([lb ub]);
% ylim([0 10]);
% savefig([save_name '_subt_contour.fig']);

figure('units', 'pixels','pos' ,[100 100 400 500]);
colormap(jet(255));
contourf(tth,time,subint',300,'LineColor','none');
xlabel('2theta (Cu K_{\alpha1})', 'fontsize', 15) ; 
ylabel('Time (h)','fontsize', 15); 
xlim([lb ub]);
% ylim([0 10]);
set(gca,'fontsize',15)
% savefig([save_name '_subt.fig']);
% saveas(gcf,[save_name '_subt.tif'])


subt = [tth,subint] ;
save([save_name '_subt.txt'],'subt','-ascii');
